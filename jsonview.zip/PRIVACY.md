PRIVACY POLICY ? JSON Nested Viewer  
Effective date: 2024-06-01

1. No data collection  
   This extension does **not** collect, transmit, or store any personal data, browsing history, or usage analytics.

2. Local processing only  
   All JSON input is processed locally in the browser; nothing is sent to any external server.

3. Third-party services  
   We do **not** integrate with any third-party service.

4. Changes  
   Any future changes to this policy will be posted in the same repository.

# jsonview
Nested JSON Viewer

1. show json str value in json view
![alt jsonview](img/1280_800%20(1).png)
2. show img in  json str value url in json view
![alt jsonview](img/p2%20(1).png)